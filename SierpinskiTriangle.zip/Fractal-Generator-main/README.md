# FractalGenerator
Creating fractals with Sierpinski Algorithm in Windows Forms.
