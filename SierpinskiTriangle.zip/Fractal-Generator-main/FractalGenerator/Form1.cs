﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FractalGenerator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private Brush selectedBrush = Brushes.GreenYellow; // 新增顏色變量
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength > 0 && Int32.Parse(textBox1.Text) >= 0)
            {
                FractalClass.ListOfTriangles.Clear();
                FractalClass.CalculateTriangle(Int32.Parse(textBox1.Text),
                                               new PointF(pictureBox1.Width / 4 + 200, pictureBox1.Height / 4 + 0),
                                               new PointF(pictureBox1.Width / 4 + 0, pictureBox1.Height / 4 + 300),
                                               new PointF(pictureBox1.Width / 4 + 400, pictureBox1.Height / 4 + 300));
                pictureBox1.Invalidate();
            }
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            if (FractalClass.ListOfTriangles.Count() > 0)
            {
                foreach (var t in FractalClass.ListOfTriangles)
                {
                    e.Graphics.FillPolygon(selectedBrush, t);
                }
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            DialogResult dr = colorDialog1.ShowDialog();
            //如果选中颜色，单击“确定”按钮则改变文本框的文本颜色
            if (dr == DialogResult.OK)
            {
                pictureBox1.BackColor = colorDialog1.Color;
            }

        }
        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult dr = colorDialog2.ShowDialog();

            if (dr == DialogResult.OK)
            {
                selectedBrush = new SolidBrush(colorDialog2.Color); 
            }
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            textBox1.Text = trackBar1.Value.ToString();
            label3.Text = "N = " + trackBar1.Value.ToString();
            button1.PerformClick();//模擬點擊第一個按鈕
        }
    }
}
